#include <stdio.h>
#include <string.h>
#include <stdlib.h>
typedef struct { 
	char *subject;
	char *instructor;
	char *location;
	char *time; //XX:XX - XX:XX
} lecture;

long int sizeOfFile(FILE *f){
	fseek (f, 0, SEEK_END);
	long int pos = ftell (f); 
	rewind (f);
	return pos;
}

int main( int argc, char *argv[] ){
	FILE *f;
	if( argc == 2 ){
		printf("The argument supplied are %s\n", argv[1]);
		f = fopen(argv[1], "r");
	}
	else if( argc > 2 ){
		printf("Too many arguments supplied, expected one.\n");
		return 1;
	}
	else{
    	printf("One argument expected.\n");
		return 1;
	}
	long int size = sizeOfFile(f);
	char data[size];
	char *index,
		 *interim = calloc(256,1),
		 *end;
	int length,
		i = 0;
	lecture semester[32];

	fread(data, size, 1, f);


	index = strstr(data, "<td class=\"time\">" + strlen("<td class=\"time\">")) + 1;
	while(strstr(index, "<table class=\"timetable\">") != NULL){
		i++;
		semester[i].time = calloc(256,1);
		semester[i].subject = calloc(256,1);
		semester[i].location = calloc(256,1);
		semester[i].instructor = calloc(256,1);
		index = index + 12;
		end = index + 5;
		length = end - index;
		strncpy(interim, index, length);
		strcpy(semester[i].time,interim);
		strcat(semester[i].time, " - ");
		//printf("%s - ", semester[i].time);
		//printf("%s - ", interim);
		memset(interim, 0, 256);
		

		index = index + 24;
		end = strchr(index, '\n');
		length = end - index;
		strncpy(interim, index, length);
		strcat(semester[i].time, interim);
		printf("%s\n", semester[i].time);
		//printf("%s\n", interim);
		memset(interim, 0, 256);
		//index = end + 1;

		index = strstr(index, "<a href=\"/tvark/timetable/subject/") + strlen("<a href=\"/tvark/timetable/subject/");
		index = strstr(index, "/\">") + strlen("/\">");
		end = strchr(index, '<');
		length = end - index;
		strncpy(interim, index, length);
		strcpy(semester[i].subject,interim);
		printf("%s\n", semester[i].subject);
		memset(interim, 0, 256);
		
		index = strstr(index, "<a href=\"/tvark/timetable/professor/") + strlen("<a href=\"/tvark/timetable/professor/");
		index = strstr(index, "/\">") + strlen("/\">");
		end = strchr(index, '<');
		length = end - index;
		strncpy(interim, index, length);
		strcpy(semester[i].instructor,interim);
		printf("%s\n", semester[i].instructor);
		memset(interim, 0, 256);
		
		index = strstr(index, "<a href=\"/tvark/timetable/classroom/") + strlen("<a href=\"/tvark/timetable/classroom/");
		index = strstr(index, "/\">") + strlen("/\">") + 47;
		end = strchr(index, '<') - 40;
		length = end - index;
		strncpy(interim, index, length);
		strcpy(semester[i].location,interim);
		printf("%s\n", semester[i].location);
		memset(interim, 0, 256);
		printf("\n");

		index = strstr(index, "<td class=\"time\">") + strlen("<td class=\"time\">") + 1;

	}
	//printf("%s testas\n", index);

	fclose(f);
	return 0;
}
